#!/bin/bash

sudo /usr/bin/ulimit -n 4096 
sudo node startup.js &
