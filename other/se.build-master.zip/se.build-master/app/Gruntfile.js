//Grunt Configure

"use strict";

module.exports = function(grunt) {
    // Do grunt-related things in here
    var $root = "/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/";
    var dest = "__build__";
    var oPath = null;
    var merge = null;

    //configure
    var conf = null;

    merge = null;
    
    oPath = {"lib":"css/lib/","mod":"css/mod/","logic":"css/logic/"};

    conf = {"cssmin":{"lib":{"options":{"banner":"/*! Copyright (c) ZUIKU.COM - Author: LIJUN - Email: zwlijun@gmail.com */\n"},"files":{"/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/__build__/css/lib/animate.css":["/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/css/lib/animate.css"],"/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/__build__/css/lib/animate222.css":["/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/css/lib/animate222.css"],"/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/__build__/css/lib/animate备份.css":["/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/css/lib/animate备份.css"],"/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/__build__/css/lib/g-edit.css":["/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/css/lib/g-edit.css"],"/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/__build__/css/lib/g.css":["/data/wwwroot/seshenghuo/build.seshenghuo.com/projects/zuiku.webapp.online.v1/res/css/lib/g.css"]}},"mod":{"options":{"banner":"/*! Copyright (c) ZUIKU.COM - Author: LIJUN - Email: zwlijun@gmail.com */\n"},"files":{}},"logic":{"options":{"banner":"/*! Copyright (c) ZUIKU.COM - Author: LIJUN - Email: zwlijun@gmail.com */\n"},"files":{}}},"concat":{"dist":{"options":{"process":true},"files":{}}}};

    conf.pkg = grunt.file.readJSON('package.json');

    if("concat" in conf 
            && conf.concat 
            && conf.concat.dist 
            && conf.concat.dist.options 
            && conf.concat.dist.options.process){
            
        conf["concat"].dist.options.process = function(src, filepath){
            var banner = (function find(path){
                var root = $root + dest + "/";
                var mlist = null;
                var tmp = null;

                for(var key in merge){ // group
                    if(merge.hasOwnProperty(key)){
                        root += oPath[key];

                        for(var f in merge[key]){ // files
                            if(merge[key].hasOwnProperty(f)){
                                mlist = merge[key][f];

                                for(var i = 0, size = mlist.length; i < size; i++){
                                    tmp = root + mlist[i].file;

                                    if(tmp == path){
                                        return mlist[i].banner;
                                    }
                                }
                            }
                        }
                    }
                }

                return "";
            })(filepath);

            return banner + src;
        }
    }

    grunt.initConfig(conf);

    //load npm task
    grunt.loadNpmTasks("grunt-contrib-cssmin");
grunt.loadNpmTasks("grunt-contrib-concat");


    //regist task
    grunt.registerTask("default", ["cssmin", "concat"]);


};